package com.example.ex2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import kotlin.math.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etInput = findViewById<EditText>(R.id.etInput)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnSubtract = findViewById<Button>(R.id.btnSubtract)
        val btnMultiply = findViewById<Button>(R.id.btnMultiply)
        val btnDivide = findViewById<Button>(R.id.btnDivide)
        val btnSin = findViewById<Button>(R.id.btnSin)
        val btnCos = findViewById<Button>(R.id.btnCos)
        val btnTan = findViewById<Button>(R.id.btnTan)
        val btnSqrt = findViewById<Button>(R.id.btnSqrt)
        val btnPow = findViewById<Button>(R.id.btnPow)
        val btnLog = findViewById<Button>(R.id.btnLog)
        val btnMod = findViewById<Button>(R.id.btnMod)

        btnAdd.setOnClickListener {
            calculateTwoInputs("+", etInput, tvResult)
        }

        btnSubtract.setOnClickListener {
            calculateTwoInputs("-", etInput, tvResult)
        }

        btnMultiply.setOnClickListener {
            calculateTwoInputs("*", etInput, tvResult)
        }

        btnDivide.setOnClickListener {
            calculateTwoInputs("/", etInput, tvResult)
        }

        btnSin.setOnClickListener {
            val input = etInput.text.toString().toDoubleOrNull()
            input?.let {
                val result = sin(Math.toRadians(it))
                tvResult.text = "Result: $result"
            } ?: showError()
        }

        btnCos.setOnClickListener {
            val input = etInput.text.toString().toDoubleOrNull()
            input?.let {
                val result = cos(Math.toRadians(it))
                tvResult.text = "Result: $result"
            } ?: showError()
        }

        btnTan.setOnClickListener {
            val input = etInput.text.toString().toDoubleOrNull()
            input?.let {
                val result = tan(Math.toRadians(it))
                tvResult.text = "Result: $result"
            } ?: showError()
        }

        btnSqrt.setOnClickListener {
            val input = etInput.text.toString().toDoubleOrNull()
            input?.let {
                if (it >= 0) {
                    val result = sqrt(it)
                    tvResult.text = "Result: $result"
                } else {
                    tvResult.text = "Error: Negative number!"
                }
            } ?: showError()
        }

        btnPow.setOnClickListener {
            calculateTwoInputs("^", etInput, tvResult)
        }

        btnLog.setOnClickListener {
            val input = etInput.text.toString().toDoubleOrNull()
            input?.let {
                if (it > 0) {
                    val result = ln(it)
                    tvResult.text = "Result: $result"
                } else {
                    tvResult.text = "Error: Input must be > 0!"
                }
            } ?: showError()
        }

        btnMod.setOnClickListener {
            calculateTwoInputs("%", etInput, tvResult)
        }
    }

    private fun calculateTwoInputs(operation: String, etInput: EditText, tvResult: TextView) {
        val inputText = etInput.text.toString()
        val numbers = inputText.split(" ")
        if (numbers.size != 2) {
            tvResult.text = "Enter two numbers separated by space."
            return
        }

        val a = numbers[0].toDoubleOrNull()
        val b = numbers[1].toDoubleOrNull()

        if (a == null || b == null) {
            showError()
            return
        }

        val result = when (operation) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            "/" -> if (b != 0.0) a / b else "Error: Divide by zero"
            "^" -> a.pow(b)
            "%" -> a % b
            else -> "Unknown operation"
        }

        tvResult.text = "Result: $result"
    }

    private fun showError() {
        Toast.makeText(this, "Invalid input!", Toast.LENGTH_SHORT).show()
    }
}
