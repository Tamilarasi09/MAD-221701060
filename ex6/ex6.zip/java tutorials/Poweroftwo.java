import java.util.Scanner;

public class Poweroftwo {

    public static boolean checkPower(int n){
        return (n & n-1) == 0;
    }
    public static void main(String [] args){
         Scanner scan = new Scanner(System.in);
         System.out.println("enter number:");
         int num = scan.nextInt();
         System.out.print(checkPower(num));
         scan.close();
    }
}
