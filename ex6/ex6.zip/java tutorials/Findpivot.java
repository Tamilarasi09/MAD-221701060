import java.util.Scanner;

public class Findpivot {

    public static int searchPivot(int [] arr){
        int sum = 0;
        for(int i =0; i < arr.length; i++){
            if(sum + arr[i] == arr[arr.length-1]){
                return i+1;
            }
        }

        return -1;
    }
    public static void main(String args []){
        Scanner scan = new Scanner(System.in);
        System.out.println("enter size:");
        int size = scan.nextInt();
        int [] arr = new int [size];
        for(int i =0; i  < size; i++){
            arr[i] = scan.nextInt();
        }

        System.out.println(searchPivot(arr));
    }
}
