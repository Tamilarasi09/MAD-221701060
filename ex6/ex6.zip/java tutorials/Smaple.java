import java.util.HashSet;

class Smaple{
    public static void main(String [] args){
           HashSet<Integer> hs = new HashSet<Integer>();

           for(int i=0; i<5; i++){
              hs.add(i);
           }
           hs.add(3);
           hs.add(4);
           hs.add(4);

           for(int i : hs){
              System.out.print(i+" ");
           }
    }
}