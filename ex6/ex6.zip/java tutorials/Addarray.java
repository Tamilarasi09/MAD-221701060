import java.util.*;

public class Addarray {

    public static void fixArrayelements(int a, int b, int k, int [] arr){
        for(int i = a-1; i <= b-1; i++){
             arr[i] += k;
        }
    }
    public static void main(String [] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("enter array size:");
        int size = scan.nextInt();
        int [] arr = new int [size];
        Arrays.fill(arr,0);

        for(int i =0; i < 3; i++){
            System.out.println("enter a,b and k:");
            int a = scan.nextInt();
            int b = scan.nextInt();
            int k = scan.nextInt();

            fixArrayelements(a,b,k,arr);
        }

       Arrays.sort(arr);
       System.out.print(arr[size-1]);

        scan.close();
    }
}
