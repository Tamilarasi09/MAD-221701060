import java.util.*;

public class Arrayrange {

    public static int returnRange(int [] arr, int low, int high){
        int count = 0;
        for(int i = 0; i < arr.length; i++){
            if(arr[i] >= low && arr[i] <= high){
                count++;
            }
        }

        return count;
    }
    public static void main(String [] args){
        Scanner scan = new Scanner(System.in);
        System.out.println("enter array size:");
        int size = scan.nextInt();
        int arr [] = new int [size];

        for(int i =0; i < size; i++){
            arr[i] = scan.nextInt();
        }
        
        for(int i =0;  i< 2; i++){
            System.out.println("enter low range:");
            int low = scan.nextInt();

            System.out.println("enter high range:");
            int high = scan.nextInt();

            System.out.println(returnRange(arr,low,high));

        }
        scan.close();
    }
}
