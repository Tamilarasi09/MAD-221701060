class Myexception extends Exception{
    public String toString(){
         return "x is equal to 0";
    }
}
 
public class Test{
    public static void main(String [] args){
        int x = 0;
        try{
        if(x == 0){    
        throw new Myexception();
        }

        }
        catch(Myexception e){
            System.out.println(e);
        }    
    }
}