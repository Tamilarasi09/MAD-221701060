import java.util.Scanner;

public class Countones{
    public static void main(String [] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("how many number will be inputted:");
        int size = scan.nextInt();
        int arr [] = new int [size];
        System.out.print("enter array elements:");
        for(int i =0; i < size; i++){
            arr[i] = scan.nextInt();
        }

        for (int num : arr) {
            int tmp = num;
            int count = 0;
            while(num > 0){
                if((num & 1) == 1){
                    count++;
                }
                num >>= 1;
            }

            System.out.println("number of ones in binary "+ tmp +" is "+ count);
            
        }

        scan.close();
        
    }
}
